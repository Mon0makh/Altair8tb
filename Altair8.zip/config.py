# Test Bot
# TG_TOKEN = '1410585073:AAEbtgPOyYtxXx8c1DJhZIxOmK2RlP5Q8vA'

# Prod bot
TG_TOKEN = '1201835732:AAGZvoD1hfjQFTg2a6oDG6zEFuWOFyasZCc'

MONGODB_LINK = "mongodb+srv://Altair8:neiQRDwaAGS6ay1a@altair8cluster.htdco.mongodb.net/HUB?retryWrites=true&w=majority"
MONGO_DB = "HUB"